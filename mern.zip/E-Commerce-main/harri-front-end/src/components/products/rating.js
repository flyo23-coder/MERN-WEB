// RatingFull
export function RatingFull() {
  return (
    <span>
      <i className="icon_star"></i>
    </span>
  );
}
// RatingHalf
export function RatingHalf() {
  return (
    <span>
      <i className="icon_star_alt"></i>
    </span>
  );
}
